package ca.gbc.comp3074.gym_application;

public class Gyms {
    public String gymName;
    public String gymDescription;
    public String gymId;
    public String gymLatitude;
    public String loggedUserRole;
    public int gymPicId;
    public int gymPopUpMenuId;
}

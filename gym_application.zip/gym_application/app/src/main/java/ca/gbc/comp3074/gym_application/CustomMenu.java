package ca.gbc.comp3074.gym_application;

public class CustomMenu {

}
